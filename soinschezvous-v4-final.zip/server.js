
const express = require("express");
const helmet = require("helmet");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_PATH || path.join(__dirname, "soinschezvous.db"));

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS nurses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 city TEXT NOT NULL,
 zip TEXT DEFAULT '',
 specialty TEXT DEFAULT 'Soins infirmiers à domicile',
 zone TEXT DEFAULT '',
 availability TEXT DEFAULT 'À confirmer',
 verified INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS patients (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id INTEGER NOT NULL,
 nurse_id INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'Nouvelle demande',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES patients(id),
 FOREIGN KEY(nurse_id) REFERENCES nurses(id)
);
`);

const count = db.prepare("SELECT COUNT(*) c FROM nurses").get().c;
if (!count) {
 const add = db.prepare(`INSERT INTO nurses(name,city,zip,specialty,zone,availability,verified) VALUES(?,?,?,?,?,?,?)`);
 const seed = db.transaction(()=>{
  add.run("Sophie Martin","Créteil","94000","Soins infirmiers à domicile","Créteil · Val-de-Marne","À confirmer",1);
  add.run("Karim Ben Ali","Maisons-Alfort","94700","Pansements · injections","Maisons-Alfort · Créteil","À confirmer",1);
  add.run("Claire Dubois","Lyon","69000","Soins post-opératoires","Lyon et alentours","À confirmer",1);
 });
 seed();
}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"SoinsChezVous",version:"4.0.0"}));

app.get("/api/nurses",(req,res)=>{
 const q = String(req.query.q||"").trim().toLowerCase();
 let rows;
 if(q){
   const like=`%${q}%`;
   rows=db.prepare(`SELECT id,name,city,zip,specialty,zone,availability,verified
     FROM nurses WHERE lower(name) LIKE ? OR lower(city) LIKE ? OR lower(zip) LIKE ?
     OR lower(specialty) LIKE ? OR lower(zone) LIKE ? ORDER BY verified DESC,name`).all(like,like,like,like,like);
 } else {
   rows=db.prepare(`SELECT id,name,city,zip,specialty,zone,availability,verified FROM nurses ORDER BY verified DESC,name`).all();
 }
 res.json(rows);
});

app.post("/api/patients",(req,res)=>{
 const name=String(req.body.name||"").trim();
 const email=String(req.body.email||"").trim();
 if(!name) return res.status(400).json({error:"Le nom est obligatoire."});
 const info=db.prepare("INSERT INTO patients(name,email) VALUES(?,?)").run(name,email);
 res.status(201).json({id:info.lastInsertRowid,name,email});
});

app.post("/api/requests",(req,res)=>{
 const patientId=Number(req.body.patientId);
 const nurseId=Number(req.body.nurseId);
 if(!patientId || !nurseId) return res.status(400).json({error:"Patient et infirmier requis."});
 const patient=db.prepare("SELECT id FROM patients WHERE id=?").get(patientId);
 const nurse=db.prepare("SELECT id FROM nurses WHERE id=?").get(nurseId);
 if(!patient || !nurse) return res.status(404).json({error:"Ressource introuvable."});
 const info=db.prepare("INSERT INTO requests(patient_id,nurse_id) VALUES(?,?)").run(patientId,nurseId);
 res.status(201).json({id:info.lastInsertRowid,status:"Nouvelle demande"});
});

app.get("/api/patients/:id/requests",(req,res)=>{
 const id=Number(req.params.id);
 const rows=db.prepare(`SELECT r.id,r.status,r.created_at,n.id nurse_id,n.name nurse,n.city
   FROM requests r JOIN nurses n ON n.id=r.nurse_id
   WHERE r.patient_id=? ORDER BY r.id DESC`).all(id);
 res.json(rows);
});

app.get("/api/admin/summary",(req,res)=>{
 const nurses=db.prepare("SELECT COUNT(*) c FROM nurses").get().c;
 const patients=db.prepare("SELECT COUNT(*) c FROM patients").get().c;
 const requests=db.prepare("SELECT COUNT(*) c FROM requests").get().c;
 const recent=db.prepare(`SELECT r.id,p.name patient,n.name nurse,r.status,r.created_at
   FROM requests r JOIN patients p ON p.id=r.patient_id JOIN nurses n ON n.id=r.nurse_id
   ORDER BY r.id DESC LIMIT 20`).all();
 res.json({nurses,patients,requests,recent});
});

app.get("*",(req,res)=>{
 if(req.path.startsWith("/api/")) return res.status(404).json({error:"API route introuvable"});
 res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`SoinsChezVous V4 listening on ${PORT}`));
