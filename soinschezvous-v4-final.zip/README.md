# SoinsChezVous V4

## Ce qui a été amélioré
- Front-end responsive conservé et modernisé.
- API serveur Express.
- Base SQLite pour la démonstration.
- Profils infirmiers servis par le backend.
- Création de patients.
- Création et consultation des demandes.
- Tableau de bord administratif relié à l'API.
- Structure directement déployable sur Render.

## Lancer en local
```bash
npm install
npm start
```
Puis ouvrir `http://localhost:3000`.

## Déploiement Render
- Repository GitHub : pousser tout le contenu du projet.
- Render : créer un **Web Service**.
- Build Command : `npm install`
- Start Command : `npm start`
- Node version : utiliser une version LTS récente.

## Important
Cette V4 est une base technique de démonstration. Elle ne doit pas recevoir de données de santé réelles.
Avant exploitation réelle : authentification serveur, gestion fine des rôles et permissions, chiffrement, journalisation, sauvegardes, gestion des secrets, conformité RGPD, analyse juridique et infrastructure adaptée aux données de santé doivent être ajoutés et validés.
